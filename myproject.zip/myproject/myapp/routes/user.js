var express = require('express');
var router = express.Router();
const bodyParser = require('body-parser');
var db = require('../database');
const nodemailer = require('nodemailer');
var otpGenerator = require('otp-generator');
var session = require('express-session');

router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: false }));

var sql1 = 'SELECT * FROM otpgen';
  db.query(sql1,function (err1, record) 	{
		if (err1) throw err1;
		if(record.length!=0)	{
			
        record.forEach(function(data)		{
			if(((new Date() - data.created_at)/1000) > 30.0) {
			var sql2 = "DELETE FROM otpgen WHERE emailAddress = '"+data.emailAddress+"' AND otp = '"+data.otp+"'";
			db.query(sql2,function (err2, record) 	{
				if (err2) throw err2;
			});
			}
		});
	}
});

router.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));

router.get('/add',(req, res) => {
    res.render('add_user', {
        title : 'CRUD Operation using NodeJS / ExpressJS / MySQL', Name:req.session.name,
    });
});

router.post('/create', function(req, res, next) {
  if (req.session.loggedin) {
  // store all the user input data
  const userDetails = {fullName:req.body.fullName,emailAddress:req.body.emailAddress,city:req.body.city,state:req.body.state,created_at:new Date(),dob:req.body.dob};
 
  // insert user data into users table
  var sql = 'INSERT INTO users SET ?';
  db.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
         console.log("Data inserted successfully "); 
  });
 res.redirect('/homepage');  // redirect to user form page after inserting the data
 }
	else	res.render('login', {log:'Login First'});
}); 

// this script to fetch data from MySQL databse table
router.get('/homepage', function(req, res, next) {
	if (req.session.loggedin) {
			var sql='SELECT * FROM users';
			db.query(sql, function (err, data, fields) {
			if (err) throw err;
			res.render('user_list', { title: 'Click on the below button to add a new user', Name:req.session.name, userData: data});
		});
	}
	else	res.render('login', {log:'Login First'});
});

router.post('/home', function(req, resp, next) {
	var username = req.body.userName;
	var pasd = req.body.pass;
	if(username && pasd)	{
		db.query('SELECT * FROM accounts WHERE emailAddress = ? AND pass = ?',[username,pasd],function(err,res,fields)	{
			if(res.length > 0)	{
				req.session.loggedin = true;
				req.session.name = res[0].fullName;
				req.session.username = res[0].emailAddress;
				resp.redirect('/homepage');
		} else 
				resp.render('login', {log:'Incorrect Username/Password'});
		});
	}
});
		

router.get('/edit/:userId',function(req, res) {
	 if (req.session.loggedin) {
    const userId = req.params.userId;
    let sql = 'Select * from users where id = '+userId;
    db.query(sql,function(err, result) {
        if(err) throw err;
        res.render('user_edit', {
            title : 'Edit the data for '+result[0].fullName,
            user : result[0],
			 Name:req.session.name
        });
    });
  }
	else	res.render('login', {log:'Login First'});
});

router.post('/update',(req, res) => {
	if (req.session.loggedin) {
    const userId = req.body.id;
    let sql = "update users SET fullName='"+req.body.fullName+"',  emailAddress='"+req.body.emailAddress+"',  city='"+req.body.city+"', state='"+req.body.state+"' where id ="+userId;
    db.query(sql,function(err, results) {
      if(err) throw err;
    });
	res.redirect('/homepage');
	}
	else	res.render('login', {log:'Login First'});
});
 
 
router.get('/delete/:userId',(req, res) => {
	if (req.session.loggedin) {
    const userId = req.params.userId;
    let sql = 'DELETE from users where id = '+userId;
    db.query(sql,(err, result) => {
        if(err) throw err;        
    });
	res.redirect('/homepage');
	}
	else	res.render('login', {log:'Login First'});
});

let transporter = nodemailer.createTransport({
    host: 'smtp.googlemail.com',
    port: 465,
    auth: {
    user: 'contact.schoolrules@gmail.com ',
    pass: 'rules@2020'
    },
    tls: {
        rejectUnauthorized: false
    }
});

router.get('/',(req, res) => {
	if (req.session.loggedin) 
		res.redirect('/homepage');
	else
		res.render('login', {log:' '});
});

router.get('/signup',(req, res) => {
    if (req.session.loggedin) 
		res.redirect('/homepage');
	else
		res.render('registration', {log:' '});
});

router.get('/login',(req, res) => {
    if (req.session.loggedin) 
		res.redirect('/homepage');
	else
		res.render('login', {log:' '});
});

router.get('/del_acnt',(req, res) => {
	if (req.session.loggedin) {
    res.render('del_acnt', {Name:req.session.name, log:' '});
	}
	else	res.render('login', {log:'Login First'});
});

router.post('/reg',(req, res) => {
    
	let otp = otpGenerator.generate(6, { upperCase: false, specialChars: false });
    let to_email = req.body.emailAddress;
    let mail_subject = 'Confirm Your Account';
    let message = '<html> <body> <p> Hi '+req.body.fullName+',</p> <p> Confirm your account by entering this OTP "'+otp+'" and clicking on Submit.</p> <p> Regards,</p> <p> \n Star Coder Billu</p> </body> </html>';
	const acntDetails = {fullName:req.body.fullName, emailAddress:req.body.emailAddress, phone:req.body.phone, pasd:req.body.pasd, onetime:otp};
	const userDetails = {emailAddress:req.body.emailAddress,otp:otp,created_at:new Date()};
	var cpasd = req.body.cpasd;
  
  if(cpasd == acntDetails.pasd)		{
  var sql = 'INSERT INTO otpgen SET ?';
  db.query(sql, userDetails,function (err, data) { 
      if (err) throw err;
          
  });
 
    let messageOptions = {
        from: 'Personal Project <contact.schoolrules@gmail.com>',
        to: to_email,
        subject: mail_subject,
        html: message
    };
 
    transporter.sendMail(messageOptions, (error, info) => {
        if (error) {
            return console.log(error);
        }
        console.log('OTP sent: %s', info.messageId, info.response);       
    });
	res.render('acc_conf', {
        details : acntDetails, log:' '
    });
  }
  else res.render('registration', {
        log:'Error ! Your Passwords do not match. Try again.'
    });
});

router.post('/conf', function(req, res, next) {
	
  const acntDet = {fullName:req.body.fullName, emailAddress:req.body.emailAddress, phone:req.body.phone, pass:req.body.pasd, created_at:new Date() };
  var otp1 = req.body.otp1;
  var otp2 = req.body.otp2;
  const acntDet1 = {fullName:req.body.fullName, emailAddress:req.body.emailAddress, phone:req.body.phone, pasd:req.body.pasd, onetime:req.body.otp1 };
	if(otp1 == otp2)	{
		var sql = 'INSERT INTO accounts SET ?';
			db.query(sql, acntDet,function (err, data) { 
      		if (err) throw err;
				console.log("Data inserted successfully "); 
			});
		 res.render('login', {
        log:'Hello '+acntDet.fullName+', your account has been created successfully. Fill up your credentials to login.'
    });
		}
	else res.render('acc_conf', {
        log:'Error ! Your OTP is incorrect. Try again or go back to the Sign Up Page by clicking Cancel.',
		details:acntDet1
    });
}); 

router.get('/logout',function(req,res)	{
   if (req.session.loggedin) {
   sessionData = req.session; 
    sessionData.destroy(function(err) {
        if(err){
            msg = 'Error destroying session';
            res.json(msg);
        }else{
            res.render('login', {log:'You have logged out Successfully !'});
        }
    });
   }
	else	res.render('login', {log:'Login First'});
});

router.post('/delete_acnt',function(req,resp)	{
	if (req.session.loggedin) {
	var username = req.session.username;
	var pasd = req.body.pass;
    db.query('SELECT * FROM accounts WHERE emailAddress = ? AND pass = ?',[username,pasd], function(err,res,fields)	{
		if(res.length > 0)	{
			var usermame = res[0].emailAddress;
			var pasd = res[0].pass;
				var sql3 = 'DELETE FROM accounts WHERE emailAddress = "'+ res[0].emailAddress +'" AND pass = "'+ res[0].pass +'"';
				db.query(sql3,(err, result) => {
					if(err) throw err; 
					resp.render('login', {log:'Your Account was Deleted Successfully !'});
				});	
		}
		else 
			resp.render('del_acnt', {log:'Invalid Username/Password !'});
	});		
	}
		else res.render('login', {log:'Login First'});
});

module.exports = router;