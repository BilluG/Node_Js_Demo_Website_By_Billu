const path = require('path');
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();
var db = require('./database');
 
//set views file
app.set('views',path.join(__dirname,'views'));
var userRouter = require('./routes/user');
app.use('/',userRouter);			
			
//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
 
// Server Listening
app.listen(3000, () => {
    console.log('Server is running at port 3000');
});